import React, { useState } from 'react';
import { TestResult, Page } from '../types';
import {
  FileCheck2,
  Download,
  Printer,
  Globe,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Award,
  BarChart3,
  ExternalLink,
  ShieldCheck,
  Check,
  History,
  Sparkles,
} from 'lucide-react';

interface TestReportPageProps {
  reports: TestResult[];
  onNavigate: (page: Page) => void;
}

export const TestReportPage: React.FC<TestReportPageProps> = ({ reports, onNavigate }) => {
  const [selectedReportId, setSelectedReportId] = useState<string>(
    reports.length > 0 ? reports[0].id : ''
  );
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const report = reports.find((r) => r.id === selectedReportId) || reports[0];

  const handleDownloadPdf = () => {
    setDownloadSuccess(true);
    setTimeout(() => {
      window.print();
      setDownloadSuccess(false);
    }, 400);
  };

  if (!report) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
          No Test Reports Found
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Run a visual test first to view and download your comprehensive audit report.
        </p>
        <button
          onClick={() => onNavigate('visual-testing')}
          className="px-6 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-md"
        >
          Run Visual Test Now
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 print:p-0">
      
      {/* Top Controls Bar (Hidden during printing) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-sm">
        
        {/* Report Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <History className="w-5 h-5 text-blue-600 shrink-0" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0">
            Reports History:
          </span>
          {reports.map((r) => (
            <button
              key={r.id}
              onClick={() => setSelectedReportId(r.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono transition-all shrink-0 ${
                r.id === report.id
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {r.id}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleDownloadPdf}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-md transition-all flex items-center gap-2"
            id="download-pdf-btn"
          >
            {downloadSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>Preparing PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download Report (PDF)</span>
              </>
            )}
          </button>
          <button
            onClick={() => window.print()}
            className="p-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            title="Print Report"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Official Executive Test Report Printable Document Container */}
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-10 shadow-xl space-y-8 print:border-none print:shadow-none print:bg-white print:text-black"
        id="printable-report-document"
      >
        
        {/* Report Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-extrabold text-xs uppercase tracking-widest mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Official Executive QA Inspection Audit</span>
            </div>
            <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white print:text-black">
              UI/UX Visual Testing Report
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-1">
              Report ID: {report.id} • Auditor Engine: v2.4 (College Final-Year Benchmark)
            </p>
          </div>

          <div className="bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60 p-4 rounded-2xl text-right shrink-0">
            <span className="text-[10px] font-bold text-blue-800 dark:text-blue-300 uppercase tracking-widest block">
              Overall Status
            </span>
            <span className="text-2xl font-black text-blue-700 dark:text-blue-400 font-mono">
              {report.overallStatus}
            </span>
          </div>
        </div>

        {/* Metadata Details Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 p-4 rounded-2xl">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-blue-500" />
              <span>Website URL</span>
            </span>
            <p className="text-sm font-bold text-slate-900 dark:text-white font-mono truncate print:text-black">
              {report.url}
            </p>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-blue-500" />
              <span>Test Date & Time</span>
            </span>
            <p className="text-sm font-bold text-slate-900 dark:text-white font-mono print:text-black">
              {new Date(report.testDate).toLocaleDateString()} {new Date(report.testDate).toLocaleTimeString()}
            </p>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block flex items-center gap-1">
              <BarChart3 className="w-3.5 h-3.5 text-blue-500" />
              <span>Target Viewport</span>
            </span>
            <p className="text-sm font-bold text-slate-900 dark:text-white font-mono uppercase print:text-black">
              {report.device} Mode
            </p>
          </div>
        </div>

        {/* Executive Metrics Score Grid */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider print:text-black">
            Core Quality Score Breakdown
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            
            {/* UI Score */}
            <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center space-y-1">
              <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 uppercase">
                UI Score
              </span>
              <div className="text-3xl font-black text-blue-600 dark:text-blue-400 font-mono">
                {report.uiScore}%
              </div>
            </div>

            {/* UX Score */}
            <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center space-y-1">
              <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 uppercase">
                UX Score
              </span>
              <div className="text-3xl font-black text-blue-600 dark:text-blue-400 font-mono">
                {report.uxScore}%
              </div>
            </div>

            {/* Performance Score */}
            <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center space-y-1">
              <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 uppercase">
                Performance
              </span>
              <div className="text-3xl font-black text-blue-600 dark:text-blue-400 font-mono">
                {report.performanceScore}%
              </div>
            </div>

            {/* Accessibility Score */}
            <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center space-y-1">
              <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 uppercase">
                Accessibility
              </span>
              <div className="text-3xl font-black text-blue-600 dark:text-blue-400 font-mono">
                {report.accessibilityScore}%
              </div>
            </div>

            {/* Responsive Score */}
            <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center space-y-1">
              <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 uppercase">
                Responsive
              </span>
              <div className="text-3xl font-black text-blue-600 dark:text-blue-400 font-mono">
                {report.responsiveScore}%
              </div>
            </div>

          </div>
        </div>

        {/* Executive Summary */}
        <div className="p-5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-2">
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
            Executive Auditor Summary
          </h4>
          <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium print:text-black">
            {report.summary}
          </p>
        </div>

        {/* Visual Difference Callouts Table */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider print:text-black">
            Pixel-Level Visual Diffs & Layout Alignment
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold uppercase">
                  <th className="py-3 px-4">DOM Component</th>
                  <th className="py-3 px-4">Design Spec Standard</th>
                  <th className="py-3 px-4">Detected Layout</th>
                  <th className="py-3 px-4 text-right">Match Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {report.visualDiffs.map((diff, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white print:text-black">
                      {diff.element}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300 print:text-black font-mono">
                      {diff.standard}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300 print:text-black font-mono">
                      {diff.detected}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                      {diff.score}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Audit Item Details Table */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider print:text-black">
            Detailed Audit Checklist Findings
          </h3>
          <div className="space-y-2">
            {report.keyFindings.map((finding) => (
              <div
                key={finding.id}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-blue-600 dark:text-blue-400 uppercase font-mono">
                      [{finding.category}]
                    </span>
                    <span className="font-bold text-slate-900 dark:text-white print:text-black">
                      {finding.title}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 print:text-black">
                    {finding.description}
                  </p>
                </div>
                <div className="px-3 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded-lg font-bold shrink-0">
                  Status: {finding.severity.toUpperCase()}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Official Signature Footer */}
        <div className="pt-8 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div>
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              UI/UX Visual Testing System • Automated QA Certified
            </p>
            <p className="text-[10px]">College Final-Year Software Engineering Project</p>
          </div>
          <div className="text-right font-mono">
            <span>Verified Token: PASS-2026-QA</span>
          </div>
        </div>

      </div>

    </div>
  );
};
